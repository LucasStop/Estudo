export const ScrollTo = (id) => {
  const elemento = document?.getElementById(id);
  elemento?.scrollIntoView();
};
